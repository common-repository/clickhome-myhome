=== MyHome Default ===

Author: ClickHome
Author URI: http://www.clickhome.com.au/
Contributors: ClickHome, athemes
Template: astrid
Tags: clickhome, myhome
Requires at least: 4.0
Tested up to: 4.4.2
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

	
== Description ==

MyHome Defaultis a child theme of Astrid by athemes, for use with plugin 'ClickHome-MyHome'.

ClickHome is a leading solution for residential construction companies. It covers the full range of residential construction building company processes, from the first point of contact with the client, to managing the work processes with trades, suppliers and subcontractors, right through to ongoing care and maintenance. The WordPress module enables existing ClickHome clients to easily develop an engaging website for their clients.

	
== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select 'ClickHome-MyHome-Theme.zip' & click Install now.
3. Activate 'MyHome Default' to use your new theme right away.
	
	
== Changelog ==

= 1.0 - June 2016 =
* Initial release